<template>
    <main class="main">
        <div class="wrapper main__wrapper">
            <h2 class="main__title">404</h2>
            <p class="main__subtitle">Извините, данной страницы не существует</p>

        </div>

    </main>
</template>

<script>

export default {
  name: 'ErrorPage'
}
</script>