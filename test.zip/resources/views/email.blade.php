<p>{{$text['name']}}</p>
<p>{{$text['phone']}}</p>
<p>{{$text['type']}}</p>
<p>{{$text['message']}}</p>